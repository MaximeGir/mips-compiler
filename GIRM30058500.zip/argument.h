/*
 *
 * @author : Maxime Girard 
 * @CodePermanent : GIRM30058500
 *
 */
 
#ifndef ARGUMENT_H
#define ARGUMENT_H

int valider_nombre_argument(int nombre_argument);
int valider_nom_fichier(char *nom_fichier);

#endif
