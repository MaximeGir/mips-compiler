/*
 *
 * @author : Maxime Girard 
 * @CodePermanent : GIRM30058500
 *
 */
 
#ifndef DICTIONNAIRE_H
 #define DICTIONNAIRE_H

char dictionnaireType(char * mot);
int dictionnaireOpCode(char * mot);
int dictionnaireRegistre(char * mot);
int dictionnaireFunction(char * mot);
int dictionnaireValeurImmediate(char * mot);

#endif
